<?php
defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

do_action( 'woocommerce_before_main_content' );
?>

<div class="custom-single-product-wrapper">

    <?php
    while ( have_posts() ) :
        the_post();

        wc_get_template_part( 'content', 'single-product' );

    endwhile;
    ?>

</div>

<section class="related-products-section">
    <h2>🔥 You Might Also Like</h2>
    <?php
    woocommerce_output_related_products();
    ?>
</section>

<?php
do_action( 'woocommerce_after_main_content' );

do_action( 'woocommerce_sidebar' );

get_footer( 'shop' );
