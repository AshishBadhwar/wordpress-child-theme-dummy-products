<?php

// Enqueue Parent & Child Styles

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'storefront-parent-style',
        get_template_directory_uri() . '/style.css'
    );

    wp_enqueue_style(
        'storefront-child-style',
        get_stylesheet_uri(),
        array('storefront-parent-style')
    );
});


// WooCommerce Customizations

add_action('after_setup_theme', function () {
    add_theme_support('woocommerce');
});

// Add Trust Badges Below "Add to Cart"
add_action('woocommerce_after_add_to_cart_button', function () {
    echo '<div class="trust-badges">✅ Free Shipping | 🔒 Secure Checkout | 💬 24/7 Support</div>';
});

// Move Short Description Above Price
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
add_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 5);

// Add "Back to Shop" Link
add_action('woocommerce_before_main_content', function () {
    if (is_product()) {
        echo '<a class="back-to-shop" href="' . esc_url(wc_get_page_permalink('shop')) . '">← Back to Shop</a>';
    }
}, 5);

// Custom Sale Badge Text
add_filter('woocommerce_sale_flash', function ($html, $post, $product) {
    return '<span class="onsale">🔥 Special Offer</span>';
}, 10, 3);

// Change Number of Products per Row on Shop Page
add_filter('loop_shop_columns', function () {
    return 3; // products per row
});


// Extra CSS Output (Inline for Demo)

add_action('wp_head', function () {
    ?>
    <style>
        .back-to-shop {
            display: inline-block;
            margin-bottom: 15px;
            text-decoration: none;
            font-size: 14px;
            color: #0073aa;
        }
        .back-to-shop:hover {
            text-decoration: underline;
        }

        .trust-badges {
            margin-top: 10px;
            font-size: 14px;
            color: #333;
        }

        .onsale {
            background: #ff4d4d !important;
            color: #fff !important;
            padding: 5px 10px;
            border-radius: 3px;
            font-weight: bold;
        }
    </style>
    <?php
});
